#!usr/bin env python

import argparse
from omxcontrol import *

import subprocess, time
import RPi.GPIO as GPIO
INPUT_PIN = 31

GPIO.setmode(GPIO.BOARD) ## Use board pin numbering
GPIO.setup(INPUT_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)

video_started = False
play_process = None
val = -1
video = '/home/pi/deathsml_15-07-2015_1cc_h264-21.mp4'

#omx = OmxControl(user=args.user, name=args.name)
omx = OmxControl()

while True:
    val = GPIO.input(INPUT_PIN)
    if val == 0: # Button pressed
        print("Button pressed")
        if not video_started:
            omx.action(OmxControl.ACTION_EXIT)
            #play_process = subprocess.Popen(['omxplayer','-o', 'local', video], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True)
    if play_process != None:
        video_started = play_process.poll() == None
    else:
        video_started = False
    print("Video started : %s" % video_started)
    time.sleep(0.2)



#parser = argparse.ArgumentParser()
#parser.add_argument("cmd", help="omxplayer command")
#parser.add_argument("-u", "--user", dest="user", help="omxplayer user")
#parser.add_argument("-n", "--name", dest="name", help="omxplayer D-Bus name")
#args = parser.parse_args()

#try:
#    omx = OmxControl(user=args.user, name=args.name)

#    if args.cmd == "1": omx.action(OmxControl.ACTION_DECREASE_SPEED)
#    elif args.cmd == "2": omx.action(OmxControl.ACTION_INCREASE_SPEED)
#    elif args.cmd == "<": omx.action(OmxControl.ACTION_REWIND)
#    elif args.cmd == ">": omx.action(OmxControl.ACTION_FAST_FORWARD)
#    elif args.cmd == "z": print(omx.properties())
#    elif args.cmd == "j": omx.action(OmxControl.ACTION_PREVIOUS_AUDIO)
#    elif args.cmd == "k": omx.action(OmxControl.ACTION_NEXT_AUDIO)
#    elif args.cmd == "i": omx.action(OmxControl.ACTION_PREVIOUS_CHAPTER)
#    elif args.cmd == "o": omx.action(OmxControl.ACTION_NEXT_CHAPTER)
#    elif args.cmd == "n": omx.action(OmxControl.ACTION_PREVIOUS_SUBTITLE)
#    elif args.cmd == "m": omx.action(OmxControl.ACTION_NEXT_SUBTITLE)
#    elif args.cmd == "s": omx.action(OmxControl.ACTION_TOGGLE_SUBTITLE)
#    elif args.cmd == "w": omx.showSubtitles()
#    elif args.cmd == "x": omx.hideSubtitles()
#    elif args.cmd == "d": omx.action(OmxControl.ACTION_DECREASE_SUBTITLE_DELAY)
#    elif args.cmd == "f": omx.action(OmxControl.ACTION_INCREASE_SUBTITLE_DELAY)
#    elif args.cmd == "q": omx.quit()
#    elif args.cmd == "p": omx.pause()
#    elif args.cmd == "-": omx.action(OmxControl.ACTION_DECREASE_VOLUME)
#    elif args.cmd == "+" or args.cmd == "=": omx.action(OmxControl.ACTION_INCREASE_VOLUME)
#    elif args.cmd == "<<": omx.action(OmxControl.ACTION_SEEK_BACK_SMALL)
#    elif args.cmd == ">>": omx.action(OmxControl.ACTION_SEEK_FORWARD_SMALL)
#    elif args.cmd == "<<<": omx.action(OmxControl.ACTION_SEEK_BACK_LARGE)
#    elif args.cmd == ">>>": omx.action(OmxControl.ACTION_SEEK_FORWARD_LARGE)

#except OmxControlError as ex:
#    print(ex.message)
