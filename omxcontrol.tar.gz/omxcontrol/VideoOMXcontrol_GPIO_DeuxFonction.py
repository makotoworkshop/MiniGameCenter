#!/usr/bin/env python2.7
# coding: utf-8
# on importe les modules nécessaires

# À FAIRE :
# - Démarrer les vidéos avec un niveau sonnore bas
# -
from omxcontrol import *
import subprocess, time
import RPi.GPIO as GPIO
import os, sys

#############
# Init GPIO #
#############
PIN_PLAY = 31           # GPIO06, Play/Pause/Stop
PIN_VOLMOINS = 35       # GPIO19, Volume -
PIN_VOLPLUS = 37        # GPIO26, Volume +
PIN_PRECEDENT = 38      # GPIO20, Précédent
PIN_SUIVANT = 36        # GPIO16, Suivant

GPIO.setmode(GPIO.BOARD) ## Use board pin numbering
GPIO.setup(PIN_PLAY, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(PIN_VOLMOINS, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(PIN_VOLPLUS, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(PIN_PRECEDENT, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(PIN_SUIVANT, GPIO.IN, pull_up_down=GPIO.PUD_UP)

####################
# Ressources Vidéo #
####################
#video1 = '/home/pi/deathsml_15-07-2015_1cc_h264-21.mp4'
#video2 = '/home/pi/dodonpachi_23-02-2014_montage.avi'
#video3 = '/home/pi/deathsml_15-07-2015_1cc_h264-21.mp4'
#video4 = '/home/pi/dodonpachi_23-02-2014_montage.avi'
def Selection(i):
    switcher={
        0:'/home/pi/deathsml_15-07-2015_1cc_h264-21.mp4',
        1:'/home/pi/dodonpachi_23-02-2014_montage.avi',
        2:'/home/pi/deathsml_15-07-2015_1cc_h264-21.mp4',
        3:'/home/pi/dodonpachi_23-02-2014_montage.avi',
        }
    return switcher.get(i,"Séléction Invalide")

#############
# Variables #
#############
vid = 0
long_press = 1
very_long_press = 3


####
# Démarrage (facultatif)
####
os.system('sudo pkill omxplayer')       # S'assure qu'aucune instance omxplayer ne tourne encore, en cas de plantage
# omxplayer /home/pi/deathsml_15-07-2015_1cc_h264-21.mp4 --aspect-mode stretch -o local
subprocess.Popen(['omxplayer','--aspect-mode', 'stretch', '-o', 'local', Selection(vid)], stdin=subprocess.PIPE)
time.sleep(3)

# fonction qui sera appelée quand on appuiera sur le bouton PIN_PLAY
def bouton_PIN_PLAY(a):
#    global PIN_PLAY
    button_press_timer = 0
    GPIO.remove_event_detect(PIN_PLAY) # empéche le bouton d'etre détecté x fois de plus
    while True:
        if(GPIO.input(a) == GPIO.LOW ): # bouton appuyé
            button_press_timer += 0.2 # incrémente tant que le bouton est maintenu

        else: # bouton relaché
            if (button_press_timer > very_long_press):
                # À DÉFINIR
                print('Fonction à définir')
            elif (button_press_timer > long_press):
                # Stoppe la vidéo
                print('Stop')
                omx.action(OmxControl.ACTION_EXIT)
                    # SORTIR DE LA BOUCLE PRINCIPALE sinon la vidéo se relancera
            elif (button_press_timer > 0):
                # Pause/Play la vidéo
                print('Pause/Play')
                omx.action(OmxControl.ACTION_PAUSE)

            button_press_timer = 0
        time.sleep(0.2)


def bouton_PIN_VOLMOINS(channel):
    print("Button Volume - pressé")
    omx.action(OmxControl.ACTION_DECREASE_VOLUME)


def bouton_PIN_VOLPLUS(channel):
    print("Button Volume + pressé")
    omx.action(OmxControl.ACTION_INCREASE_VOLUME)


def bouton_PIN_PRECEDENT(b):
    global vid
#    global PIN_PRECEDENT
    button_press_timer = 0
    GPIO.remove_event_detect(PIN_PRECEDENT) # empéche le bouton d'etre détecté x fois de plus
    while True:
        if(GPIO.input(b) == GPIO.LOW ): # bouton appuyé
            print("Button Précédent pressé")            # un appuis long pour Vidéo précédente
            button_press_timer += 0.2 # incrémente tant que le bouton est maintenu
        else: # bouton relaché
            if (button_press_timer > long_press):
                # Stopper la lecture et tombe donc en erreur via Try > Except de la boucle principale
                print('Vidéo Précédente')
                omx.action(OmxControl.ACTION_EXIT)
                vid = vid - 1       # pour lire la vidéo précédente
                if vid == -1:
                    vid = 3
                print('vid : ',vid)

            elif (button_press_timer > 0):
                # un petit saut un arriére dans la vidéo
                print('<<')
                omx.action(OmxControl.ACTION_SEEK_BACK_SMALL)

            button_press_timer = 0
        time.sleep(0.2)


def bouton_PIN_SUIVANT(c):
    global vid
#    global PIN_SUIVANT
    button_press_timer = 0
    GPIO.remove_event_detect(PIN_SUIVANT) # empéche le bouton d'etre détecté x fois de plus
    while True:
        if(GPIO.input(c) == GPIO.LOW ): # bouton appuyé
            print("Button Suivant pressé")              # un appuie long pour Vidéo suivante
            button_press_timer += 0.2 # incrémente tant que le bouton est maintenu
        else: # bouton relaché
            if (button_press_timer > long_press):
                # Stopper la lecture et tombe donc en erreur via Try > Except de la boucle principale
                print('Vidéo Suivante')
                omx.action(OmxControl.ACTION_EXIT)
                vid = vid + 1       # pour lire la vidéo suivante
                if vid == 4:
                    vid = 0
                print('vid : ',vid)

            elif (button_press_timer > 0):
                # un petit saut en avant dans la vidéo
                print('>>')
                omx.action(OmxControl.ACTION_SEEK_FORWARD_SMALL)

            button_press_timer = 0
        time.sleep(0.2)

# on met le bouton en écoute
#GPIO.add_event_detect(PIN_PLAY, GPIO.FALLING, callback=bouton_PIN_PLAY, bouncetime=100)
#GPIO.add_event_detect(PIN_VOLMOINS, GPIO.FALLING, callback=bouton_PIN_VOLMOINS, bouncetime=200)
#GPIO.add_event_detect(PIN_VOLPLUS, GPIO.FALLING, callback=bouton_PIN_VOLPLUS, bouncetime=200)
#GPIO.add_event_detect(PIN_PRECEDENT, GPIO.FALLING, callback=bouton_PIN_PRECEDENT, bouncetime=200)
#GPIO.add_event_detect(PIN_SUIVANT, GPIO.FALLING, callback=bouton_PIN_SUIVANT, bouncetime=200)

GPIO.add_event_detect(PIN_PLAY,GPIO.FALLING)
GPIO.add_event_callback(PIN_PLAY, callback=bouton_PIN_PLAY)
GPIO.add_event_detect(PIN_VOLMOINS, GPIO.FALLING)
GPIO.add_event_callback(PIN_VOLMOINS, callback=bouton_PIN_VOLMOINS)
GPIO.add_event_detect(PIN_VOLPLUS, GPIO.FALLING)
GPIO.add_event_callback(PIN_VOLPLUS, callback=bouton_PIN_VOLPLUS)
GPIO.add_event_detect(PIN_PRECEDENT, GPIO.FALLING)
GPIO.add_event_callback(PIN_PRECEDENT, callback=bouton_PIN_PRECEDENT)
GPIO.add_event_detect(PIN_SUIVANT, GPIO.FALLING)
GPIO.add_event_callback(PIN_SUIVANT, callback=bouton_PIN_SUIVANT)



#####################
# Boucle Principale #
#####################
while True:
    try:
        omx = OmxControl()      # appel librairie OmxControl

    except OmxControlError as ex:       # si le controle ne voit plus D-Bus, relance la vidéo
        print("ERROR contrôle D-Bus")
        print('Selection : ',Selection(vid))
        subprocess.Popen(['omxplayer','--aspect-mode', 'stretch', '-o', 'local', Selection(vid)], stdin=subprocess.PIPE)
        time.sleep(3)   # tempo pour laisser le temps au player vidéo de démarrer

    time.sleep(2)     # délay de répétition de pression sur le bouton si on le maintient enfoncé

# on réinitialise les ports GPIO en sortie de script
GPIO.cleanup()

#####################################################
# Fonctions disponible dans la librairie OmxControl #
#####################################################
#ACTION_DECREASE_SPEED
#ACTION_INCREASE_SPEED
#ACTION_REWIND
#ACTION_FAST_FORWARD
#ACTION_SHOW_INFO
#ACTION_PREVIOUS_AUDIO
#ACTION_NEXT_AUDIO
#ACTION_PREVIOUS_CHAPTER
#ACTION_NEXT_CHAPTER
#ACTION_PREVIOUS_SUBTITLE
#ACTION_NEXT_SUBTITLE
#ACTION_TOGGLE_SUBTITLE
#ACTION_DECREASE_SUBTITLE_DELAY
#ACTION_INCREASE_SUBTITLE_DELAY
#ACTION_EXIT
#ACTION_PAUSE
#ACTION_DECREASE_VOLUME
#ACTION_INCREASE_VOLUME
#ACTION_SEEK_BACK_SMALL
#ACTION_SEEK_FORWARD_SMALL
#ACTION_SEEK_BACK_LARGE
#ACTION_SEEK_FORWARD_LARGE
#ACTION_SEEK_RELATIVE
#ACTION_SEEK_ABSOLUTE
#ACTION_STEP
#ACTION_BLANK
#ACTION_MOVE_VIDEO
#ACTION_HIDE_VIDEO
#ACTION_UNHIDE_VIDEO
#ACTION_HIDE_SUBTITLES

