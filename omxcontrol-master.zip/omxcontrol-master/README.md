omxcontrol.py
=======

Python2 module for control of the omxplayer. 

See also https://github.com/willprice/python-omxplayer-wrapper for a similar project.

Installation
------------

    git clone https://github.com/douglas6/omxcontrol.git
    cd omxcontrol
    sudo python setup.py install
